# Sample Java Project

This is a reference for maven based project.

## Setup

Building this project by using maven .. clone this project to the workspace as maven project and try to build without offline. If you are using STS IDE maven is embeded in the library. Once build try to run the TestMain class for testing purpose.Change the log path as well as provide absolute Json path else you can use the existing Json from the provided relative path.

## Dependencies

Only Maven has to be updated and it can connect to central. Incase firewall exists in between please try to provide the defined master POM dependanies to fetch from nexus repository which in general defined by organisation . Use fiddler to download the specific dependancies jar


## Philosophy

Code is not copied.
