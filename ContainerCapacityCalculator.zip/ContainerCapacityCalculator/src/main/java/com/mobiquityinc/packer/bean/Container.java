package com.mobiquityinc.packer.bean;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Container {
	@SerializedName("capacity")
	@Expose
	private String capacity;
	@SerializedName("packets")
	@Expose
	private List<Packet> packets = null;

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public List<Packet> getPackets() {
		return packets;
	}

	public void setPackets(List<Packet> packets) {
		this.packets = packets;
	}
}