package com.mobiquityinc.packer.bean;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ContainersDetails {
	@SerializedName("containers")
	@Expose
	private List<Container> containers = null;

	public List<Container> getContainers() {
		return containers;
	}

	public void setContainers(List<Container> containers) {
		this.containers = containers;
	}
}