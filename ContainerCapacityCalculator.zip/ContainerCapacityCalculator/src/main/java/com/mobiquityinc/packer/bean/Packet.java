package com.mobiquityinc.packer.bean;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * @author C27419
 *
 */
public class Packet {
	@SerializedName("id")
	@Expose
	private String id;
	@SerializedName("weight")
	@Expose
	private String weight;
	@SerializedName("cost")
	@Expose
	private String cost;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}
}