package com.mobiquityinc.packer.calculator;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.mobiquityinc.packer.bean.Container;
import com.mobiquityinc.packer.bean.ContainersDetails;
import com.mobiquityinc.packer.bean.Packet;
import com.mobiquityinc.packer.exception.APIException;

/**
 * 
 * @author C27419
 * 
 */
public class Packer {
	private static final Logger logger = LoggerFactory.getLogger(Packer.class);

	private Packer() {
	}

	/**
	 * 
	 * @param fileName
	 * @return  a string list 
	 * @throws APIException If file path is not valid
	 */
	public static String pack(String fileName) throws APIException {
		if (StringUtils.isBlank(fileName)) {
			throw new APIException("Incorrect parameter been passed");
		}
		ContainersDetails containersDetails = readInputFile(fileName);
		List<String> output = new ArrayList<>();
		if (containersDetails != null && containersDetails.getContainers() != null
				&& !containersDetails.getContainers().isEmpty()) {
			List<Container> containers = containersDetails.getContainers();
			containers.forEach(container -> {
				List<Packet> availablePackages = container.getPackets();
				Map<String, List<Packet>> weightToPackageMapping = getCostToItemMappings(availablePackages);
				List<Double> costs = sortedPackageCostInDescOrder(weightToPackageMapping);
				List<Packet> itemsToBePacked = findElementsToBeFilledInContainer(weightToPackageMapping,
						Double.parseDouble(container.getCapacity()), costs);
				output.add(itemsToBePacked(itemsToBePacked));
			});
		}
		return String.join("\n", output);
	}

	/**
	 * 
	 * @param items
	 * @return list with comma separated values
	 */
	private static String itemsToBePacked(List<Packet> items) {
		List<String> ids = new ArrayList<>();
		items.forEach(item -> ids.add(item.getId()));
		return StringUtils.join(ids, ",");
	}
	
	/**
	 * 
	 * @param fileName Name of a absolute file
	 * @return Gson object Basically read the Json file 
	 * @throws APIException If file is not present in the absolute path
	 */

	private static ContainersDetails readInputFile(String fileName) throws APIException {
		Gson gson = new Gson();
		JsonReader reader;
		try {
			ClassPathResource resource = new ClassPathResource(fileName);
			if (!resource.getFile().exists()) {
				throw new APIException(resource.getFile().getAbsolutePath() + " does not exists");
			}
			reader = new JsonReader(new FileReader(resource.getFile()));
			return gson.fromJson(reader, ContainersDetails.class);
		} catch (IOException e) {
			logger.error("Error reading input file input.json", e);
			throw new APIException(e.getMessage());
		}
	}	
	
	/**
	 * 
	 * @param items list of packages
	 * @return map  it returns a sorted map wrt to cost as key
	 */

	private static Map<String, List<Packet>> getCostToItemMappings(List<Packet> items) {
		Map<String, List<Packet>> map = new LinkedHashMap<>();
		items.forEach(item -> {
			double cost = Double.parseDouble(item.getCost());
			double weight = Double.parseDouble(item.getWeight());
			String costWithPrecision = Double.toString(cost);
			if ((int) weight < 100 && (int) cost < 100) {
				if (map.containsKey(item.getCost())) {
					List<Packet> itemList = map.get(costWithPrecision);
					itemList.add(item);
					map.put(costWithPrecision, itemList);
				} else {
					List<Packet> itemList = new ArrayList<>();
					itemList.add(item);
					map.put(costWithPrecision, itemList);
				}
			}
		});
		map.forEach((k, v) -> {
			sortedPackagesOnWeights(v);
		});
		return map;
	}

	
	/**
	 * 
	 * @param items Compare items in the list and sort in descending order
	 */
	private static void sortedPackagesOnWeights(List<Packet> items) {
		Collections.sort(items, new Comparator<Packet>() {
			@Override
			public int compare(Packet c1, Packet c2) {
				double c1Weight = Double.parseDouble(c1.getWeight());
				double c2Weight = Double.parseDouble(c2.getWeight());
				return Double.compare(c1Weight, c2Weight);
			}
		});
	}

	/**
	 * 
	 * @param maps Takes Sorted map
	 * @return return list with sorted cost
	 */
	private static List<Double> sortedPackageCostInDescOrder(Map<String, List<Packet>> maps) {
		List<Double> costs = new ArrayList<>();
		maps.forEach((k, v) -> costs.add(Double.parseDouble(k)));
		Collections.sort(costs);
		Collections.reverse(costs);
		return costs;
	}
	
	
	/**
	 * @param maps
	 * @param capacity
	 * @param sortedCosts
	 * @return It returns sorted item with respect to capacity of the container
	 */
	private static List<Packet> findElementsToBeFilledInContainer(Map<String, List<Packet>> maps, double capacity,
			List<Double> sortedCosts) {
		List<Packet> itemsToBeAdded = new ArrayList<>();
		double totalSize = 0;
		for (int i = 0; i < sortedCosts.size(); i++) {
			List<Packet> packageItems = maps.get(Double.toString(sortedCosts.get(i)));
			if (packageItems != null) {
				for (Packet item : packageItems) {
					double weight = Double.parseDouble(item.getWeight());
					if (capacity >= (totalSize + weight) && itemsToBeAdded.size() <= 15) {
						itemsToBeAdded.add(item);
						totalSize = totalSize + weight;
					}
				}
			}
		}
		return itemsToBeAdded;
	}
}