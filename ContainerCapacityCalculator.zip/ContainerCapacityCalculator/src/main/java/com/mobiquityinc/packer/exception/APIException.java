package com.mobiquityinc.packer.exception;

public class APIException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public APIException(Exception e) {
		super(e);
	}

	public APIException(String msg) {
		super(msg);
	}
}
