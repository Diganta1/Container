package com.mobiquityinc.packer.main;

import com.mobiquityinc.packer.calculator.Packer;
import com.mobiquityinc.packer.exception.APIException;

public class TestMain {

	public static void main(String[] args) {
		try {
			System.out.println(Packer.pack("input.json"));
		} catch (APIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}